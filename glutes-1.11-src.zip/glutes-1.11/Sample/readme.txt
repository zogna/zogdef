Add HIRES.rc and resource.h to your or the sample project to enable VGA screen mode on PocketPC.
