USB Serial Terminal for Android
=====

USB Serial Terminal for Android

- char, dec, hex display setting
- baud rate and data bits, parity, stop bits, flow control, break setting
- linefeed code setting
- email result to your address

require **Physicaloid Library** project

Physicaloid Library [https://github.com/ksksue/PhysicaloidLibrary](https://github.com/ksksue/PhysicaloidLibrary "Physicaloid Library")
- support CDC-ACM
- support FTDI
- support Silicon Labs CP210x


About me
---
![twitter](http://d.hatena.ne.jp/images/icon-twitter.png "twitter") [@ksksue](http://twitter.com/#!/ksksue "twitter @ksksue")  
![icon1](http://a1.twimg.com/profile_images/549237316/twt_bigger.jpg "icon")  
Web page : Geekle Board - [http://ksksue.com/wiki/](http://ksksue.com/wiki/ "Geekle Board")  

License
----------
Copyright &copy; 2011 @ksksue
Licensed under the [Apache License, Version 2.0][Apache]

[Apache]: http://www.apache.org/licenses/LICENSE-2.0

