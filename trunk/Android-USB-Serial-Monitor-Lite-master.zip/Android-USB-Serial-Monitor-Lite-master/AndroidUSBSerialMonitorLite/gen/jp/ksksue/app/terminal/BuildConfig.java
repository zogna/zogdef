/** Automatically generated file. DO NOT MODIFY */
package jp.ksksue.app.terminal;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}